#!/usr/bin/env python
# coding: utf-8

# In[38]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import operator
import re
from sklearn.linear_model import LinearRegression
from textwrap import wrap

data1 = pd.read_csv('data/rd_expenditure.csv')
per_capita_gdp = data1['Per Capita GDP in US $']
per_capita_rd = data1['Per Capita R&D in US $']
model = LinearRegression()
X = per_capita_gdp.to_numpy().reshape(-1,1)
y = per_capita_rd.to_numpy()
model.fit(X, y)
predicted_rd = model.predict(X)
fig1 = plt.figure(1, figsize=(7,7))
ax1 = fig1.add_subplot(111)
sort_axis = operator.itemgetter(0)
sorted_zip = sorted(zip(per_capita_gdp, predicted_rd), key=sort_axis)
x, y = zip(*sorted_zip)
ax1.scatter(per_capita_gdp, per_capita_rd)
ax1.plot(x, y, c='#FFA500')
ax1.set_xlabel('Per capita GDP in US $')
ax1.set_ylabel('Per capita R&D in US $')
ax1.set_title('Per capita GDP vs per capita R&D investment')
fig1.savefig('fig1.png', format='png', dpi=300)



data2 = pd.read_csv('data/GDP_and_Major_Industrial_Sectors_of_Economy_Dataset.csv')
cols = data2.columns[8:14].to_list()
gdp_share = data2[cols].dropna().to_numpy()
labels = [re.split(r'\s-\s?Share', label)[0] for label in cols]
wrapped_labels =  [ '\n'.join(wrap(l, 15)) for l in labels ]
fig2 = plt.figure(3, figsize=(11,7))
ax2 = fig2.add_subplot(111)
ax2.boxplot(gdp_share, labels=wrapped_labels, vert=False)
ax2.xaxis.grid()
ax2.set_xlabel("Percentage share in GDP")
ax2.set_ylabel("Sectors")
ax2.set_title("Variability in contribution of different sectors to total GDP from 1951-2012")
fig2.savefig('fig2.png', format='png', dpi=300)


fig3 = plt.figure(4, figsize=(10,10))
ax3 = fig3.add_subplot(111)
for col in cols:
    ax3.plot(data2['Financial Year'],data2[col])
ax3.tick_params(axis='x', rotation=90, labelsize=8)
ax3.set_xlabel("Year")
ax3.set_ylabel("Percentage Share in GDP")
ax3.set_title("Trend in contribution of different sectors to total GDP from 1951-2012")
ax3.legend(labels)
fig3.savefig('fig3.png', format='png', dpi=300)




